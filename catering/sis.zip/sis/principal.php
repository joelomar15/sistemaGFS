<?php
    include ('conexion.php');
    include ('cabecera.php');
?>
   
<body style="background-image: url(../../fondogfs.jpg); background-size:100% 100%;background-repeat: no-repeat;">
<b><h1 style="background-color: white;color:#156f15;">Sistema de Consumos</h1></b>
        <br>