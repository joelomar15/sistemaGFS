<?php
	$db2 = new mysqli("23.229.232.4","adminstarman","gfsQwerty1.6","pedidosfedex");
	if (mysqli_connect_errno()) {
		echo "No se puede conectar 🚫";
	}
?>